"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import { authedFetch } from "@/lib/api/authedFetch";

type AnyRow = Record<string, any>;

export default function MatchmakerEventHomePage() {
  const router = useRouter();
  const params = useParams();
  const matchmakingId = String((params as any)?.matchmakingId ?? "");

  const [mm, setMm] = useState<AnyRow | null>(null);
  const [counts, setCounts] = useState<{ uploads: number; inschrijvingen: number; bouts: number }>({
    uploads: 0,
    inschrijvingen: 0,
    bouts: 0,
  });
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<string>("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!matchmakingId) return;
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matchmakingId]);

  async function load() {
    setLoading(true);
    setMsg("");

    const { data: mmRow, error: mmErr } = await supabase
      .from("matchmaker_matchmakings")
      .select("*")
      .eq("id", matchmakingId)
      .maybeSingle();
    if (mmErr) console.warn(mmErr);
    setMm(mmRow ?? null);

    const [{ count: upCount }, { count: insCount }, { count: boutCount }] = await Promise.all([
      supabase
        .from("matchmaker_uploads")
        .select("id", { count: "exact", head: true })
        .eq("matchmaker_matchmaking_id", matchmakingId),
      supabase
        .from("matchmaker_inschrijvingen")
        .select("id", { count: "exact", head: true })
        .eq("matchmaker_matchmaking_id", matchmakingId),
      supabase
        .from("matchmaker_bouts_raw")
        .select("id", { count: "exact", head: true })
        .eq("matchmaker_matchmaking_id", matchmakingId),
    ]);

    setCounts({ uploads: upCount ?? 0, inschrijvingen: insCount ?? 0, bouts: boutCount ?? 0 });
    setLoading(false);
  }

  async function runScrape() {
    try {
      setBusy(true);
      setMsg("⏳ Scraper starten…");

      const res = await authedFetch("/api/matchmaker/scrape/start", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ matchmaker_matchmaking_id: matchmakingId }),
      });

      const j = await res.json().catch(() => null);
      if (!res.ok) {
        setMsg(`❌ ${j?.error ?? "Scraper mislukt"}`);
        return;
      }
      setMsg(`✅ Scrape gestart (VA’s: ${j?.va_count ?? "?"}).`);
    } catch (e: any) {
      console.error(e);
      setMsg("❌ Onverwachte fout bij starten scraper.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-screen bg-black text-white px-4 py-8">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="rounded-2xl border p-5" style={{ borderColor: "var(--brand-orange)", background: "#111" }}>
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div>
              <div className="text-xs text-white/60">Matchmaker flow</div>
              <h1 className="text-2xl font-bold" style={{ color: "var(--brand-orange)" }}>
                {mm?.evenement_naam ?? "Evenement"}
              </h1>
              <div className="text-sm text-white/70">
                {mm?.evenement_datum ?? "—"} • bondteam {mm?.bondteam ?? "—"}
              </div>
              <div className="mt-2 text-xs text-white/60">ID: {matchmakingId}</div>
            </div>

            <div className="flex gap-2 flex-wrap">
              <button
                onClick={() => router.push("/dashboard/matchmaker/inschrijvingen")}
                className="rounded-md px-4 py-2 font-semibold border"
                style={{ borderColor: "var(--brand-orange)", color: "var(--brand-orange)" }}
              >
                ← Terug
              </button>
              <button
                onClick={() => router.push(`/dashboard/matchmaker/inschrijvingen/upload?matchmaker_matchmaking_id=${matchmakingId}`)}
                className="rounded-md px-4 py-2 font-semibold"
                style={{ background: "var(--brand-orange)", color: "black" }}
              >
                Upload inschrijvingen
              </button>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
            <div className="rounded-xl border p-3" style={{ borderColor: "rgba(255,77,0,0.35)", background: "#0c0c0c" }}>
              <div className="text-white/60">Uploads</div>
              <div className="text-xl font-extrabold">{loading ? "…" : counts.uploads}</div>
            </div>
            <div className="rounded-xl border p-3" style={{ borderColor: "rgba(255,77,0,0.35)", background: "#0c0c0c" }}>
              <div className="text-white/60">Inschrijvingen</div>
              <div className="text-xl font-extrabold">{loading ? "…" : counts.inschrijvingen}</div>
            </div>
            <div className="rounded-xl border p-3" style={{ borderColor: "rgba(255,77,0,0.35)", background: "#0c0c0c" }}>
              <div className="text-white/60">Partijen</div>
              <div className="text-xl font-extrabold">{loading ? "…" : counts.bouts}</div>
            </div>
          </div>

          <div className="mt-4 flex gap-2 flex-wrap">
            <button
              onClick={() => router.push(`/dashboard/matchmaker/inschrijvingen/${matchmakingId}/match`)}
              className="rounded-md px-4 py-2 font-semibold"
              style={{ background: "#2f2f33", border: "1px solid var(--brand-orange)", color: "white" }}
            >
              Match pagina
            </button>
            <button
              onClick={() => router.push(`/dashboard/matchmaker/inschrijvingen/uploadoverzicht/${matchmakingId}`)}
              className="rounded-md px-4 py-2 font-semibold"
              style={{ background: "#2f2f33", border: "1px solid var(--brand-orange)", color: "white" }}
            >
              Overzicht partijen
            </button>
            <button
              onClick={runScrape}
              disabled={busy}
              className="rounded-md px-4 py-2 font-semibold disabled:opacity-60"
              style={{ background: "transparent", border: "1px solid var(--brand-orange)", color: "var(--brand-orange)" }}
              title="Vult/controleert gegevens met scraper (op VA)"
            >
              {busy ? "Scrapen…" : "Scrape vechters"}
            </button>
          </div>

          {msg ? <div className="mt-3 text-sm" style={{ color: "var(--brand-orange)" }}>{msg}</div> : null}
        </div>

        <div className="text-xs text-white/50">
          Tip: upload meerdere bestanden — inschrijvingen worden toegevoegd (append). Daarna naar “Match pagina”.
        </div>
      </div>
    </main>
  );
}

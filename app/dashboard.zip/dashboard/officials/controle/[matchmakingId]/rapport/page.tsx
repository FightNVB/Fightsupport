"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { supabase } from "@/lib/supabaseClient";
import NvbTable from "@/components/NvbTable";

type PartijStatus = "OK" | "AFKEUR" | "DISPENSATIE" | "ACTIE";

type ControleRun = {
  id: string;
  matchmaking_id: string;
  status: string | null;
  gestart_op: string | null;
  afgerond_op: string | null;
  run_type: string | null;
};

type EventMeta = {
  id: string | null;
  naam: string | null;
  datum: string | null;
};

type ResultRow = {
  partij_nr: number | null;
  rule: string | null;
  rule_code: string | null;
  resultaat: string | null;
  boodschap: string | null;
  aantekeningen: string | null;
  created_at: string | null;
  review_status?: string | null;
  hoek?: "rood" | "blauw" | null;
};

type AuditEvent = {
  partij_nr: number | null;
  hoek: "rood" | "blauw" | null;
  event_type: string | null; // "RESCRAPE" | "VA_CHANGED" | "RESCRAPE_NO_VA"
  old_va: string | null;
  new_va: string | null;
  actor_email: string | null;
  created_at: string | null;
  reason: string | null;
};

function safe(v: any, fallback = "-") {
  const s = String(v ?? "").trim();
  return s ? s : fallback;
}

function fmtNlDateOnly(v: any) {
  if (!v) return "-";
  const s = String(v).trim();
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return `${m[3]}-${m[2]}-${m[1]}`;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return s;
  return d.toLocaleDateString("nl-NL", { timeZone: "Europe/Amsterdam" });
}

function fmtDateTime(v: any) {
  if (!v) return "-";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return String(v);
  return d.toLocaleString("nl-NL", { timeZone: "Europe/Amsterdam" });
}

function normCode(v: any) {
  return String(v ?? "").trim().toUpperCase();
}

function isApprovedOrClosed(review_status: any) {
  if (review_status == null) return false;
  const s = String(review_status).trim().toLowerCase();
  return (
    s === "approved" ||
    s === "approve" ||
    s === "ok" ||
    s === "goed" ||
    s === "goedgekeurd" ||
    s === "akkoord" ||
    s === "accepted" ||
    s === "yes" ||
    s === "done" ||
    s === "closed" ||
    s === "afgehandeld" ||
    s === "resolved" ||
    s === "complete" ||
    s === "completed"
  );
}

/**
 * ✅ Naam mismatch / naam anders NOOIT tonen in rapport
 * (maar "Fightpaspoort nummer gewijzigd" wél, dat is aparte melding)
 */
function isNameMismatch(row: ResultRow) {
  const c = normCode(row.rule_code);
  return c.startsWith("VECHTER_NAAM_MISMATCH") || c.startsWith("VECHTER_NAAM_ANDERS");
}

/**
 * ✅ "Fightpaspoort nummer gewijzigd" melding tonen
 * - liefst via rule_code VA_NUMMER_AANGEPAST_*
 * - maar ook tolerant: als rule/boodschap die tekst bevat
 */
function isFightpaspoortGewijzigd(row: ResultRow) {
  const c = normCode(row.rule_code);
  if (c.startsWith("VA_NUMMER_AANGEPAST")) return true;

  const r = String(row.rule ?? "").toLowerCase();
  const b = String(row.boodschap ?? "").toLowerCase();

  if (r.includes("fightpaspoort nummer gewijzigd")) return true;
  if (b.includes("fightpaspoort nummer gewijzigd")) return true;

  return false;
}

function statusFromResultaat(resultaat: any): PartijStatus {
  const s = String(resultaat ?? "").trim().toLowerCase();
  if (s === "afkeur" || s === "afgekeurd" || s === "reject" || s === "rejected") return "AFKEUR";
  if (s === "dispensatie") return "DISPENSATIE";
  if (s === "actie") return "ACTIE";
  return "OK";
}

function statusPrio(s: PartijStatus) {
  return s === "AFKEUR" ? 1 : s === "DISPENSATIE" ? 2 : s === "ACTIE" ? 3 : 9;
}

function partyStatusVoorMeldingen(meldingen: ResultRow[]): PartijStatus {
  if (!meldingen?.length) return "OK";
  let best: PartijStatus = "OK";
  let bestP = 999;
  for (const m of meldingen) {
    const st = statusFromResultaat(m.resultaat);
    const p = statusPrio(st);
    if (p < bestP) {
      bestP = p;
      best = st;
    }
  }
  return best;
}

function StatusBadge({ status }: { status: PartijStatus }) {
  const base = "inline-flex items-center rounded px-2 py-0.5 text-xs font-bold";
  if (status === "AFKEUR") return <span className={`${base} bg-red-600 text-white`}>AFKEUR</span>;
  if (status === "DISPENSATIE") return <span className={`${base} bg-yellow-500 text-black`}>DISPENSATIE</span>;
  if (status === "ACTIE") return <span className={`${base} bg-orange-500 text-black`}>ACTIE</span>;
  return <span className={`${base} bg-green-600 text-white`}>OK</span>;
}

function licentieIsProbleem(v: any) {
  const s = String(v ?? "").trim().toLowerCase();
  return s !== "ja"; // nee / null / anders -> probleem
}
function licentieLabel(v: any) {
  const s = String(v ?? "").trim().toLowerCase();
  if (!s) return "onbekend";
  return s;
}
function keurmerkIsProbleem(v: any) {
  return v === false || v == null; // ongeldig of onbekend
}

// ✅ VA "mist" check (tolerant): leeg/geen digits => mist
function vaIsMissing(v: any) {
  if (v == null) return true;
  const s = String(v).trim();
  if (!s) return true;
  const digits = s.replace(/[^0-9]/g, "");
  // jouw VA is typisch 3-5 cijfers (zoals in andere code)
  return !/^\d{3,5}$/.test(digits);
}

/**
 * ============================================================
 * ✅ DISPENSATIE-INDICATIE (voor badge + jotform link)
 * - Niet alleen resultaat === "DISPENSATIE"
 * - Ook fallback op rule_code/rule als dat dispensatie aanduidt
 * ============================================================
 */
function isDispensatieMelding(m: ResultRow) {
  const res = String(m.resultaat ?? "").trim().toLowerCase();
  if (res === "dispensatie") return true;

  const c = normCode(m.rule_code ?? m.rule);
  if (c.includes("DISPENSATIE")) return true;
  if (c.includes("KLASSE") && c.includes("VERSCHIL")) return true; // bv KLASSE_VERSCHIL_*
  return false;
}

function hasDispensatie(meldingen: ResultRow[]) {
  return (meldingen ?? []).some(isDispensatieMelding);
}

/**
 * ✅ Max 2 badges:
 * - Hoofdbadge = zwaarste status (AFKEUR > DISPENSATIE > ACTIE > OK)
 * - Extra badge = DISPENSATIE als die óók voorkomt en hoofdbadge ≠ DISPENSATIE
 */
function StatusBadges({ status, meldingen }: { status: PartijStatus; meldingen: ResultRow[] }) {
  const extraDisp = hasDispensatie(meldingen) && status !== "DISPENSATIE";
  return (
    <div className="flex items-center gap-2">
      <StatusBadge status={status} />
      {extraDisp ? <StatusBadge status="DISPENSATIE" /> : null}
    </div>
  );
}

/**
 * DISPENSATIE LINKS
 * - volwassen klasse verschil: https://form.jotform.com/252374601478056
 * - jeugd dispensatie:         https://form.jotform.com/252374582262055
 *
 * ✅ Let op: we tonen link zodra hasDispensatie(meldingen) true is,
 * ook als hoofdbadge AFKEUR is.
 */
const DISP_VOLWASSENEN = "https://form.jotform.com/252374601478056";
const DISP_JEUGD = "https://form.jotform.com/252374582262055";

function isJeugdDispensatie(meldingen: ResultRow[]) {
  for (const m of meldingen ?? []) {
    if (!isDispensatieMelding(m)) continue;
    const c = normCode(m.rule_code ?? m.rule);
    if (c.includes("JEUGD") || c.includes("YOUTH") || c.includes("CAT13") || c.includes("CAT15") || c.includes("CAT17")) {
      return true;
    }
  }
  return false;
}

function DispensatieLinks({ meldingen }: { meldingen: ResultRow[] }) {
  if (!hasDispensatie(meldingen)) return null;

  const jeugd = isJeugdDispensatie(meldingen);
  const url = jeugd ? DISP_JEUGD : DISP_VOLWASSENEN;
  const label = jeugd ? "Dispensatie jeugd (formulier)" : "Klasse verschil volwassenen (formulier)";

  return (
    <a
      href={url}
      target="_blank"
      rel="noreferrer"
      className="inline-flex items-center rounded bg-black/10 px-3 py-1.5 text-xs font-bold text-black hover:bg-black/15"
      title="Open Jotform in nieuwe tab"
    >
      {label}
    </a>
  );
}

export default function RapportPage() {
  const params = useParams();
  const matchmakingId = String((params as any)?.matchmakingId ?? "");

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [run, setRun] = useState<ControleRun | null>(null);
  const [eventMeta, setEventMeta] = useState<EventMeta | null>(null);

  const [ctxRows, setCtxRows] = useState<any[]>([]);
  const [resultaten, setResultaten] = useState<ResultRow[]>([]);
  const [auditEvents, setAuditEvents] = useState<AuditEvent[]>([]);

  useEffect(() => {
    if (!matchmakingId) return;

    (async () => {
      setLoading(true);
      setError(null);

      try {
        const { data: runRows, error: runErr } = await supabase
          .from("controle_runs")
          .select("id, matchmaking_id, status, gestart_op, afgerond_op, run_type")
          .eq("matchmaking_id", matchmakingId)
          .order("gestart_op", { ascending: false })
          .limit(1);

        if (runErr) throw runErr;
        const lastRun = (runRows ?? [])[0] ?? null;
        setRun(lastRun);

        // ===== event meta (tolerant + fallback) =====
        try {
          const { data: up, error: upErr } = await supabase
            .from("matchmaking_uploads")
            .select("evenement_naam, evenement_datum, naam, datum, event_id")
            .eq("id", matchmakingId)
            .maybeSingle();

          if (upErr) throw upErr;

          const uploadEventId = (up as any)?.event_id ? String((up as any).event_id) : null;

          // 1) probeer via events table
          if (uploadEventId) {
            const { data: ev, error: evErr } = await supabase
              .from("events")
              .select("id, naam, datum, evenement_naam, evenement_datum")
              .eq("id", uploadEventId)
              .maybeSingle();

            if (!evErr && ev) {
              setEventMeta({
                id: String((ev as any)?.id ?? uploadEventId),
                naam: (ev as any)?.naam ?? (ev as any)?.evenement_naam ?? null,
                datum: (ev as any)?.datum ?? (ev as any)?.evenement_datum ?? null,
              });
            } else {
              // 2) fallback op matchmaking_uploads velden
              setEventMeta({
                id: uploadEventId,
                naam: (up as any)?.evenement_naam ?? (up as any)?.naam ?? null,
                datum: (up as any)?.evenement_datum ?? (up as any)?.datum ?? null,
              });
            }
          } else {
            // geen event_id -> fallback op uploads velden
            setEventMeta({
              id: null,
              naam: (up as any)?.evenement_naam ?? (up as any)?.naam ?? null,
              datum: (up as any)?.evenement_datum ?? (up as any)?.datum ?? null,
            });
          }
        } catch {
          setEventMeta(null);
        }

        if (!lastRun?.id) {
          setCtxRows([]);
          setResultaten([]);
          setAuditEvents([]);
          setLoading(false);
          return;
        }

        const { data: ctx, error: ctxErr } = await supabase
          .from("controle_bout_context")
          .select("*")
          .eq("matchmaking_id", matchmakingId)
          .eq("controle_run_id", lastRun.id)
          .order("partij_nr", { ascending: true });

        if (ctxErr) throw ctxErr;
        setCtxRows(ctx ?? []);

        const { data: res, error: resErr } = await supabase
          .from("controle_resultaten")
          .select("partij_nr, rule, rule_code, resultaat, boodschap, aantekeningen, created_at, review_status, hoek")
          .eq("controle_run_id", lastRun.id);

        if (resErr) throw resErr;
        setResultaten(res ?? []);

        // ✅ Audit events (blijven bestaan na herscrape)
        const { data: aud, error: audErr } = await supabase
          .from("controle_audit_events")
          .select("partij_nr, hoek, event_type, old_va, new_va, actor_email, created_at, reason")
          .eq("controle_run_id", lastRun.id)
          .eq("matchmaking_id", matchmakingId)
          .order("created_at", { ascending: false });

        if (audErr) {
          // audit is nice-to-have: niet crashen
          console.warn("audit load failed:", audErr.message);
          setAuditEvents([]);
        } else {
          setAuditEvents((aud ?? []) as any);
        }
      } catch (e: any) {
        setError(e?.message ?? String(e));
      } finally {
        setLoading(false);
      }
    })();
  }, [matchmakingId]);

  // OPEN meldingen: alles wat NIET approved/closed is
  // + naam mismatch/anders weglaten (maar fightpaspoort gewijzigd wél meenemen)
  const openMeldingen = useMemo(() => {
    return (resultaten ?? []).filter((r) => {
      if (isApprovedOrClosed((r as any).review_status)) return false;
      if (isNameMismatch(r) && !isFightpaspoortGewijzigd(r)) return false;
      return true;
    });
  }, [resultaten]);

  const meldByPartij = useMemo(() => {
    const m = new Map<number, ResultRow[]>();
    for (const r of openMeldingen) {
      const pn = Number(r.partij_nr);
      if (!Number.isFinite(pn)) continue;
      const arr = m.get(pn) ?? [];
      arr.push(r);
      m.set(pn, arr);
    }
    for (const [pn, arr] of m.entries()) {
      arr.sort((a, b) => statusPrio(statusFromResultaat(a.resultaat)) - statusPrio(statusFromResultaat(b.resultaat)));
      m.set(pn, arr);
    }
    return m;
  }, [openMeldingen]);

  const partijenOverzicht = useMemo(() => {
    return (ctxRows ?? []).map((p: any) => {
      const pn = Number(p.partij_nr);
      const meldingen = Number.isFinite(pn) ? meldByPartij.get(pn) ?? [] : [];
      const status = partyStatusVoorMeldingen(meldingen);

      return {
        partij_label: p.partij_label ?? p.partij_nr,
        partij_nr: p.partij_nr,
        rood: safe(p.rood_naam_fp ?? p.rood_naam_mm),
        blauw: safe(p.blauw_naam_fp ?? p.blauw_naam_mm),
        discipline: safe(p.discipline),
        klasse: safe(p.klasse_mm ?? p.klasse),
        status,
        hasOpenMeldingen: meldingen.length > 0,
        meldingen,
      };
    });
  }, [ctxRows, meldByPartij]);

  const partijMetMeldingen = useMemo(() => {
    return (ctxRows ?? [])
      .map((p: any) => {
        const pn = Number(p.partij_nr);
        const meldingen = Number.isFinite(pn) ? meldByPartij.get(pn) ?? [] : [];
        if (!meldingen.length) return null;

        return {
          partij_label: p.partij_label ?? p.partij_nr,
          partij_nr: p.partij_nr,
          status: partyStatusVoorMeldingen(meldingen),
          roodNaam: safe(p.rood_naam_fp ?? p.rood_naam_mm),
          blauwNaam: safe(p.blauw_naam_fp ?? p.blauw_naam_mm),
          roodGym: safe(p.rood_gym_fp ?? p.rood_gym_mm ?? p.rood_gym),
          blauwGym: safe(p.blauw_gym_fp ?? p.blauw_gym_mm ?? p.blauw_gym),
          roodVa: safe(p.rood_va_mm ?? p.va_rood ?? p.rood_va),
          blauwVa: safe(p.blauw_va_mm ?? p.va_blauw ?? p.blauw_va),
          meldingen,
        };
      })
      .filter(Boolean) as any[];
  }, [ctxRows, meldByPartij]);

  // ✅ map partij_nr -> ctx row (voor lookup)
  const ctxByPartijNr = useMemo(() => {
    const m = new Map<number, any>();
    for (const p of ctxRows ?? []) {
      const pn = Number(p.partij_nr);
      if (!Number.isFinite(pn)) continue;
      m.set(pn, p);
    }
    return m;
  }, [ctxRows]);

  /**
   * ✅ Aandacht vereist: fightpaspoort nummer gewijzigd
   * - Eerst: audit VA_CHANGED (blijft bestaan na herscrape)
   * - Daarna: fallback op controle_resultaten (als ze er (nog) zijn)
   */
  const lijstFightpaspoortGewijzigd = useMemo(() => {
    const items: {
      partij: string;
      partij_nr: number;
      hoek: "rood" | "blauw";
      naam: string;
      gym: string;
      boodschap: string;
      created_at: string | null;
    }[] = [];

    // 1) audit-first
    for (const ev of auditEvents ?? []) {
      if (normCode(ev.event_type) !== "VA_CHANGED") continue;

      const pn = Number(ev.partij_nr);
      if (!Number.isFinite(pn)) continue;

      const hoek = (ev.hoek ?? "rood") as "rood" | "blauw";
      const ctx = ctxByPartijNr.get(pn);

      const naam =
        hoek === "rood"
          ? safe(ctx?.rood_naam_fp ?? ctx?.rood_naam_mm)
          : safe(ctx?.blauw_naam_fp ?? ctx?.blauw_naam_mm);

      const gym =
        hoek === "rood"
          ? safe(ctx?.rood_gym_fp ?? ctx?.rood_gym_mm ?? ctx?.rood_gym)
          : safe(ctx?.blauw_gym_fp ?? ctx?.blauw_gym_mm ?? ctx?.blauw_gym);

      const oldVa = safe(ev.old_va, "-");
      const newVa = safe(ev.new_va, "-");
      const actor = ev.actor_email ? ` (door: ${ev.actor_email})` : "";

      items.push({
        partij: safe(ctx?.partij_label ?? pn),
        partij_nr: pn,
        hoek,
        naam,
        gym,
        boodschap: `Fightpaspoort nummer gewijzigd: ${oldVa} → ${newVa}. Pas aan op MM.${actor}`,
        created_at: ev.created_at ?? null,
      });
    }

    // 2) fallback: resultaten (zonder duplicates)
    const seen = new Set(items.map((x) => `${x.partij_nr}-${x.hoek}`));

    for (const r of openMeldingen ?? []) {
      if (!isFightpaspoortGewijzigd(r)) continue;

      const pn = Number(r.partij_nr);
      if (!Number.isFinite(pn)) continue;

      const ctx = ctxByPartijNr.get(pn);
      const hoek = (r.hoek ?? (normCode(r.rule_code).includes("_BLAUW") ? "blauw" : "rood")) as "rood" | "blauw";

      const key = `${pn}-${hoek}`;
      if (seen.has(key)) continue;

      const naam =
        hoek === "rood"
          ? safe(ctx?.rood_naam_fp ?? ctx?.rood_naam_mm)
          : safe(ctx?.blauw_naam_fp ?? ctx?.blauw_naam_mm);

      const gym =
        hoek === "rood"
          ? safe(ctx?.rood_gym_fp ?? ctx?.rood_gym_mm ?? ctx?.rood_gym)
          : safe(ctx?.blauw_gym_fp ?? ctx?.blauw_gym_mm ?? ctx?.blauw_gym);

      items.push({
        partij: safe(ctx?.partij_label ?? pn),
        partij_nr: pn,
        hoek,
        naam,
        gym,
        boodschap: safe(r.boodschap ?? r.rule ?? "Fightpaspoort nummer gewijzigd", "-"),
        created_at: r.created_at ?? null,
      });
    }

    items.sort((a, b) => {
      if (a.partij_nr !== b.partij_nr) return a.partij_nr - b.partij_nr;
      return a.hoek.localeCompare(b.hoek);
    });

    return items;
  }, [auditEvents, openMeldingen, ctxByPartijNr]);

  // ===== aparte lijsten =====
  const lijstLicentie = useMemo(() => {
    const items: {
      partij: string;
      hoek: "rood" | "blauw";
      naam: string;
      gym: string;
      licentie: string;
      ookGeenVa: boolean;
    }[] = [];

    for (const p of ctxRows ?? []) {
      const partij = safe(p.partij_label ?? p.partij_nr);

      const roodVa = p.rood_va_mm ?? p.va_rood ?? p.rood_va;
      const blauwVa = p.blauw_va_mm ?? p.va_blauw ?? p.blauw_va;

      if (licentieIsProbleem(p.rood_licentie)) {
        items.push({
          partij,
          hoek: "rood",
          naam: safe(p.rood_naam_fp ?? p.rood_naam_mm),
          gym: safe(p.rood_gym_fp ?? p.rood_gym_mm ?? p.rood_gym),
          licentie: licentieLabel(p.rood_licentie),
          ookGeenVa: vaIsMissing(roodVa),
        });
      }
      if (licentieIsProbleem(p.blauw_licentie)) {
        items.push({
          partij,
          hoek: "blauw",
          naam: safe(p.blauw_naam_fp ?? p.blauw_naam_mm),
          gym: safe(p.blauw_gym_fp ?? p.blauw_gym_mm ?? p.blauw_gym),
          licentie: licentieLabel(p.blauw_licentie),
          ookGeenVa: vaIsMissing(blauwVa),
        });
      }
    }

    const score = (x: string) => (x === "nee" ? 1 : x === "onbekend" ? 2 : 9);
    const toNum = (s: string) => {
      const m = String(s ?? "").match(/^\d+/);
      return m ? Number(m[0]) : 999999;
    };

    return items.sort((a, b) => {
      const sa = score(a.licentie);
      const sb = score(b.licentie);
      if (sa !== sb) return sa - sb;

      if (a.ookGeenVa !== b.ookGeenVa) return a.ookGeenVa ? -1 : 1;

      const na = toNum(a.partij);
      const nb = toNum(b.partij);
      if (na !== nb) return na - nb;

      return a.hoek.localeCompare(b.hoek);
    });
  }, [ctxRows]);

  const lijstKeurmerkSportscholen = useMemo(() => {
    const set = new Set<string>();
    for (const p of ctxRows ?? []) {
      const roodGym = safe(p.rood_gym_fp ?? p.rood_gym_mm ?? p.rood_gym, "");
      const blauwGym = safe(p.blauw_gym_fp ?? p.blauw_gym_mm ?? p.blauw_gym, "");
      if (roodGym && keurmerkIsProbleem(p.keurmerk_rood)) set.add(roodGym);
      if (blauwGym && keurmerkIsProbleem(p.keurmerk_blauw)) set.add(blauwGym);
    }
    return Array.from(set).sort((a, b) => a.localeCompare(b, "nl"));
  }, [ctxRows]);

  const lijstStartverbod = useMemo(() => {
    const items: { partij: string; hoek: "rood" | "blauw"; naam: string; gym: string }[] = [];
    for (const p of ctxRows ?? []) {
      const partij = safe(p.partij_label ?? p.partij_nr);

      if (p.rood_heeft_startverbod === true) {
        items.push({
          partij,
          hoek: "rood",
          naam: safe(p.rood_naam_fp ?? p.rood_naam_mm),
          gym: safe(p.rood_gym_fp ?? p.rood_gym_mm ?? p.rood_gym),
        });
      }
      if (p.blauw_heeft_startverbod === true) {
        items.push({
          partij,
          hoek: "blauw",
          naam: safe(p.blauw_naam_fp ?? p.blauw_naam_mm),
          gym: safe(p.blauw_gym_fp ?? p.blauw_gym_mm ?? p.blauw_gym),
        });
      }
    }

    const toNum = (s: string) => {
      const m = String(s ?? "").match(/^\d+/);
      return m ? Number(m[0]) : 999999;
    };

    return items.sort((a, b) => {
      const na = toNum(a.partij);
      const nb = toNum(b.partij);
      if (na !== nb) return na - nb;
      return a.hoek.localeCompare(b.hoek);
    });
  }, [ctxRows]);

  return (
    <div className="bg-white text-zinc-900">
      {/* header */}
      <div className="bg-[#0d0d0d] text-white">
        <div className="mx-auto max-w-5xl px-6 py-5">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-4">
              {/* ✅ Logo */}
              <img src="/branding/fightsupport/logo-light.png" alt="FightSupport" className="h-12 w-auto rounded bg-white/5 p-1" />

              <div>
                <div className="text-2xl font-bold">NVB Controle Rapport</div>
                <div className="mt-1 text-sm text-white/90">
                  Evenement: <span className="font-semibold">{eventMeta?.naam ?? "-"}</span> • Datum:{" "}
                  <span className="font-semibold">{fmtNlDateOnly(eventMeta?.datum)}</span>
                </div>
                <div className="mt-1 text-xs text-white/70">
                  Matchmaking ID: <span className="font-mono">{matchmakingId}</span>
                </div>
                <div className="mt-1 text-xs text-white/60">
                  Run: {safe(run?.status)} • Gestart: {fmtDateTime(run?.gestart_op)} • Afgerond: {fmtDateTime(run?.afgerond_op)}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Link
                href={`/dashboard/officials/controle/${matchmakingId}`}
                className="rounded bg-white/10 px-3 py-2 text-sm font-semibold hover:bg-white/15"
              >
                Terug
              </Link>
              <button
                onClick={() => window.print()}
                className="rounded bg-[var(--brand-orange)] px-3 py-2 text-sm font-bold text-black hover:bg-orange-500"
              >
                Print / PDF
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-5xl px-6 py-6 space-y-6">
        {loading && <div className="rounded border border-zinc-200 bg-zinc-50 p-4 text-sm">Rapport laden…</div>}
        {error && <div className="rounded border border-red-200 bg-red-50 p-4 text-sm text-red-800">{error}</div>}

        {!loading && !error && (
          <>
            {/* Overzicht ALLE partijen — zebra via NvbTable */}
            <div className="rounded-xl border border-zinc-200 bg-white shadow-sm overflow-hidden">
              <div className="bg-[var(--brand-orange)] px-4 py-3 font-bold text-black">Overzicht partijen (alle)</div>

              <div className="p-3">
                <NvbTable columns={["Partij", "Partij", "Status"]}>
                  {partijenOverzicht.map((r, i) => (
                    <tr key={`${r.partij_nr}-${i}`}>
                      <td className="px-4 py-2 font-semibold">{safe(r.partij_label)}</td>
                      <td className="px-4 py-2">
                        <div className="font-medium">
                          {r.rood} <span className="opacity-70">vs</span> {r.blauw}
                        </div>
                        <div className="text-xs opacity-80">
                          {r.discipline} • {r.klasse}
                          {r.hasOpenMeldingen ? " • open meldingen" : ""}
                        </div>

                        {/* ✅ Jotform link zodra er dispensatie is (ook als hoofdbadge AFKEUR is) */}
                        {hasDispensatie(r.meldingen) ? (
                          <div className="mt-2">
                            <DispensatieLinks meldingen={r.meldingen} />
                          </div>
                        ) : null}
                      </td>
                      <td className="px-4 py-2">
                        {/* ✅ Max 2 badges incl. dispensatie */}
                        <StatusBadges status={r.status} meldingen={r.meldingen} />
                      </td>
                    </tr>
                  ))}
                </NvbTable>
              </div>
            </div>

            {/* ✅ AANDACHT VEREIST — onder partijen, boven licentie/keurmerk/startverbod */}
            <div className="rounded-xl border border-zinc-200 bg-white shadow-sm overflow-hidden">
              <div className="bg-[var(--brand-orange)] px-4 py-3 font-bold text-black">Aandacht vereist</div>

              <div className="p-3 space-y-4">
                {/* Fightpaspoort nummer gewijzigd */}
                <div className="rounded-lg border border-zinc-200 bg-zinc-50 p-3">
                  <div className="flex items-center justify-between gap-3">
                    <div className="font-semibold">Fightpaspoort nummer gewijzigd</div>
                    <span className="text-xs font-bold text-zinc-700">{lijstFightpaspoortGewijzigd.length}</span>
                  </div>

                  {lijstFightpaspoortGewijzigd.length === 0 ? (
                    <div className="mt-2 text-sm text-zinc-600">Geen.</div>
                  ) : (
                    <div className="mt-3">
                      <NvbTable columns={["Partij", "Hoek", "Naam", "Sportschool", "Melding"]}>
                        {lijstFightpaspoortGewijzigd.map((x, i) => (
                          <tr key={`fpchg-${x.partij_nr}-${x.hoek}-${i}`}>
                            <td className="px-4 py-2 font-semibold">{x.partij}</td>
                            <td className="px-4 py-2">{x.hoek}</td>
                            <td className="px-4 py-2">{x.naam}</td>
                            <td className="px-4 py-2">{x.gym}</td>
                            <td className="px-4 py-2">
                              <div>{x.boodschap}</div>
                              {x.created_at ? (
                                <div className="mt-1 text-xs text-zinc-600">({fmtDateTime(x.created_at)})</div>
                              ) : null}
                            </td>
                          </tr>
                        ))}
                      </NvbTable>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Aparte lijsten */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Licentie */}
              <div className="rounded-xl border border-zinc-200 bg-white shadow-sm overflow-hidden">
                <div className="bg-[#0d0d0d] text-white px-4 py-3 font-bold">Licentie (nee/onbekend)</div>
                <div className="p-3">
                  {lijstLicentie.length === 0 ? (
                    <div className="text-sm text-zinc-600">Geen.</div>
                  ) : (
                    <ul className="space-y-2 text-sm">
                      {lijstLicentie.map((x, idx) => (
                        <li key={`lic-${idx}`} className="rounded border border-zinc-200 bg-zinc-50 p-2">
                          <div className="flex items-center justify-between gap-2">
                            <div className="font-semibold">
                              {x.partij} • {x.hoek}
                            </div>

                            <div className="flex items-center gap-2">
                              {x.ookGeenVa ? (
                                <span className="rounded bg-orange-100 px-2 py-0.5 text-xs font-bold text-orange-800">
                                  ook geen VA
                                </span>
                              ) : null}
                              <span className="text-xs font-bold text-red-700">licentie: {x.licentie}</span>
                            </div>
                          </div>

                          <div className="mt-1">{x.naam}</div>
                          <div className="text-xs text-zinc-600">{x.gym}</div>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              {/* Keurmerk sportscholen */}
              <div className="rounded-xl border border-zinc-200 bg-white shadow-sm overflow-hidden">
                <div className="bg-[#0d0d0d] text-white px-4 py-3 font-bold">Keurmerk (sportscholen)</div>
                <div className="p-3">
                  <div className="text-xs text-zinc-500 mb-2">Ongeldig of onbekend (uniek)</div>
                  {lijstKeurmerkSportscholen.length === 0 ? (
                    <div className="text-sm text-zinc-600">Geen.</div>
                  ) : (
                    <ul className="space-y-1 text-sm">
                      {lijstKeurmerkSportscholen.map((gym, idx) => (
                        <li key={`keur-${idx}`} className="rounded border border-zinc-200 bg-zinc-50 px-2 py-1">
                          {gym}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              {/* Startverbod */}
              <div className="rounded-xl border border-zinc-200 bg-white shadow-sm overflow-hidden">
                <div className="bg-[#0d0d0d] text-white px-4 py-3 font-bold">Startverbod (true)</div>
                <div className="p-3">
                  {lijstStartverbod.length === 0 ? (
                    <div className="text-sm text-zinc-600">Geen.</div>
                  ) : (
                    <ul className="space-y-2 text-sm">
                      {lijstStartverbod.map((x, idx) => (
                        <li key={`sv-${idx}`} className="rounded border border-red-200 bg-red-50 p-2">
                          <div className="font-semibold">
                            {x.partij} • {x.hoek}
                          </div>
                          <div className="mt-1">{x.naam}</div>
                          <div className="text-xs text-zinc-700">{x.gym}</div>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </div>

            {/* Onderaan: detailblokken met open meldingen */}
            <div className="space-y-6">
              {partijMetMeldingen.map((it, idx) => (
                <div
                  key={`partij-${safe(it.partij_nr)}-${idx}`}
                  className="rounded-xl border border-zinc-200 bg-white shadow-sm overflow-hidden"
                >
                  <div className="flex items-center justify-between gap-3 bg-[var(--brand-orange)] px-4 py-3">
                    <div className="font-bold text-black">Partij {safe(it.partij_label)}</div>

                    <div className="flex items-center gap-2">
                      {/* ✅ Jotform link zodra er dispensatie is (ook als hoofdbadge AFKEUR is) */}
                      <DispensatieLinks meldingen={it.meldingen} />

                      {/* ✅ Max 2 badges incl. dispensatie */}
                      <StatusBadges status={it.status} meldingen={it.meldingen} />
                    </div>
                  </div>

                  <div className="px-4 py-4">
                    <div className="grid gap-3 sm:grid-cols-2">
                      <div className="rounded-lg border border-zinc-200 bg-zinc-50 p-3">
                        <div className="text-xs font-semibold text-zinc-600">Rood</div>
                        <div className="mt-1 font-semibold">{it.roodNaam}</div>
                        <div className="text-sm text-zinc-700">
                          {it.roodGym} • VA: {it.roodVa}
                        </div>
                      </div>

                      <div className="rounded-lg border border-zinc-200 bg-zinc-50 p-3">
                        <div className="text-xs font-semibold text-zinc-600">Blauw</div>
                        <div className="mt-1 font-semibold">{it.blauwNaam}</div>
                        <div className="text-sm text-zinc-700">
                          {it.blauwGym} • VA: {it.blauwVa}
                        </div>
                      </div>
                    </div>

                    <div className="mt-4">
                      <div className="text-sm font-semibold">Open meldingen</div>

                      {/* Meldingen zebra ook via NvbTable */}
                      <div className="mt-2">
                        <NvbTable columns={["Resultaat", "Regel", "Melding"]}>
                          {it.meldingen.map((m: ResultRow, i: number) => {
                            const st = statusFromResultaat(m.resultaat);
                            const code = safe(m.rule_code ?? m.rule);
                            const msg = safe(m.boodschap ?? "", "-");
                            const aant = safe(m.aantekeningen ?? "", "");

                            return (
                              <tr key={`${safe(it.partij_nr)}-${i}`}>
                                <td className="px-4 py-2">
                                  <StatusBadge status={st} />
                                </td>
                                <td className="px-4 py-2 font-mono text-xs">{code}</td>
                                <td className="px-4 py-2">
                                  <div>{msg}</div>
                                  {aant && (
                                    <div className="mt-1 text-xs opacity-80">
                                      <span className="font-semibold">Aantekeningen:</span> {aant}
                                    </div>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </NvbTable>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {partijMetMeldingen.length === 0 && (
                <div className="rounded border border-zinc-200 bg-zinc-50 p-4 text-sm text-zinc-700">
                  Geen open meldingen.
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

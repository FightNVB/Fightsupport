"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import TableCardLayout from "@/components/TableCardLayout";
import { supabase } from "@/lib/supabaseClient";
import { authedFetch } from "@/lib/api/authedFetch";

type AnyRow = Record<string, any>;

type ControleRun = {
  id: string;
  matchmaking_id: string;
  status: string;
  gestart_op: string | null;
  afgerond_op: string | null;
  run_type: string | null;
};

type PartijStatus = "afgekeurd" | "dispensatie" | "actie" | "ok" | "geen_info";

type ResRow = {
  partij_nr: number | null;
  hoek?: "rood" | "blauw" | null;
  resultaat: "ok" | "actie" | "dispensatie" | "afgekeurd" | string;
  rule: string | null;
  rule_code?: string | null;
  boodschap: string | null;
};

type FilterKey = "all" | "verbod" | "afgekeurd" | "dispensatie" | "actie" | "ok" | "geen_info";

function parseISODateOnly(d?: any): Date | null {
  if (!d) return null;
  const s = String(d).trim();
  const dt = new Date(s.length === 10 ? `${s}T00:00:00` : s);
  return isNaN(dt.getTime()) ? null : dt;
}

function calcAgeYearsOnDate(eventDate: Date, birthDate: Date): number | null {
  let years = eventDate.getFullYear() - birthDate.getFullYear();
  const m = eventDate.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && eventDate.getDate() < birthDate.getDate())) years -= 1;
  if (years < 0 || !Number.isFinite(years)) return null;
  return years;
}

function ageAtEvent(ctx: AnyRow, side: "rood" | "blauw"): string {
  const event = parseISODateOnly(ctx?.evenement_datum);
  const birth = parseISODateOnly(ctx?.[`${side}_geboortedatum_fp`] ?? ctx?.[`${side}_geboortedatum_mm`]);
  if (!event || !birth) return "-";
  const years = calcAgeYearsOnDate(event, birth);
  return years == null ? "-" : String(years);
}

function safeText(v: any, fallback = "-") {
  const s = String(v ?? "").trim();
  return s.length ? s : fallback;
}

/** ✅ Context compleet? (anders = GEEN INFO) */
function isContextCompleet(ctx: AnyRow): boolean {
  if (!ctx) return false;
  const required = [
    ctx?.rood_va_mm,
    ctx?.blauw_va_mm,
    ctx?.rood_naam_fp,
    ctx?.blauw_naam_fp,
    ctx?.rood_geboortedatum_fp,
    ctx?.blauw_geboortedatum_fp,
    ctx?.rood_geslacht,
    ctx?.blauw_geslacht,
    ctx?.evenement_datum,
  ];
  return required.every((v) => v != null && String(v).trim() !== "");
}

function normResultaat(v: any): string {
  const s = String(v ?? "").trim().toLowerCase();
  if (!s) return "";
  if (s === "afkeur" || s === "afgekeur" || s === "afgekeurd" || s === "afkeuren") return "afgekeurd";
  if (s === "actie" || s === "waarschuwing") return "actie";
  if (s === "dispensatie" || s === "disp") return "dispensatie";
  if (s === "ok" || s === "goedgekeurd") return "ok";
  if (s === "info") return "ok";
  return s;
}

function statusFromResultaten(resultaten: ResRow[]): PartijStatus {
  let s: PartijStatus = "geen_info";
  for (const r of resultaten) {
    const res = normResultaat(r?.resultaat);
    if (res === "afgekeurd") return "afgekeurd";
    if (res === "dispensatie" || res === "actie") {
      s = s === "geen_info" || s === "ok" ? "actie" : s;
    }
    if (res === "ok") s = s === "geen_info" ? "ok" : s;
  }
  return s;
}

function statusFromResultatenOrOk(resultaten: ResRow[] | undefined, ctxRow: AnyRow): PartijStatus {
  if (!isContextCompleet(ctxRow)) return "geen_info";
  if (!resultaten || resultaten.length === 0) return "ok";
  return statusFromResultaten(resultaten);
}

/** ===== UI badges ===== */
function HeaderBadge({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone: "red" | "yellow" | "orange" | "gray" | "green" | "white" | "blue" | "purple";
}) {
  const cls =
    tone === "red"
      ? "bg-red-500 text-white"
      : tone === "yellow"
      ? "bg-yellow-300 text-black"
      : tone === "orange"
      ? "bg-orange-600 text-white"
      : tone === "green"
      ? "bg-green-500 text-white"
      : tone === "blue"
      ? "bg-blue-700 text-white"
      : tone === "purple"
      ? "bg-purple-700 text-white"
      : tone === "white"
      ? "bg-white/90 text-black"
      : "bg-gray-500 text-white";

  return (
    <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold ${cls}`}>
      <span>{label}</span>
      <span className="tabular-nums">{value}</span>
    </span>
  );
}

function Chip({
  label,
  tone,
}: {
  label: string;
  tone: "red" | "yellow" | "orange" | "gray" | "green" | "white" | "purple";
}) {
  const cls =
    tone === "red"
      ? "bg-red-500 text-white"
      : tone === "yellow"
      ? "bg-yellow-300 text-black"
      : tone === "orange"
      ? "bg-orange-600 text-white"
      : tone === "green"
      ? "bg-green-500 text-white"
      : tone === "purple"
      ? "bg-purple-700 text-white"
      : tone === "white"
      ? "bg-white/90 text-black"
      : "bg-gray-500 text-white";

  return <span className={`px-2 py-1 rounded text-[11px] font-extrabold ${cls}`}>{label}</span>;
}

function StatusBadge({ status }: { status: PartijStatus }) {
  if (status === "afgekeurd") return <Chip label="AFKEUR" tone="red" />;
  if (status === "dispensatie") return <Chip label="DISPENSATIE" tone="orange" />;
  if (status === "actie") return <Chip label="ACTIE" tone="yellow" />;
  if (status === "ok") return <Chip label="OK" tone="green" />;
  return <Chip label="GEEN INFO" tone="white" />;
}

/** ===== Filter button ===== */
function FilterButton({
  label,
  active,
  onClick,
  count,
  tone,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
  count: number;
  tone: "red" | "yellow" | "orange" | "gray" | "green" | "white" | "neutral" | "purple";
}) {
  const base = "inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-extrabold border transition";

  const activeCls =
    tone === "red"
      ? "bg-red-500 text-white border-red-500"
      : tone === "yellow"
      ? "bg-yellow-300 text-black border-yellow-300"
      : tone === "orange"
      ? "bg-orange-600 text-white border-orange-600"
      : tone === "green"
      ? "bg-green-500 text-white border-green-500"
      : tone === "purple"
      ? "bg-purple-700 text-white border-purple-700"
      : tone === "white"
      ? "bg-white text-black border-white"
      : tone === "gray"
      ? "bg-gray-500 text-white border-gray-500"
      : "bg-white/10 text-white border-white/10";

  const inactiveCls =
    tone === "red"
      ? "bg-black/30 text-red-200 border-red-500/60 hover:bg-red-500/15"
      : tone === "yellow"
      ? "bg-black/30 text-yellow-200 border-yellow-300/70 hover:bg-yellow-300/15"
      : tone === "orange"
      ? "bg-black/30 text-orange-200 border-orange-500/70 hover:bg-orange-500/15"
      : tone === "green"
      ? "bg-black/30 text-green-200 border-green-500/60 hover:bg-green-500/15"
      : tone === "purple"
      ? "bg-black/30 text-purple-200 border-purple-700/60 hover:bg-purple-700/15"
      : tone === "white"
      ? "bg-black/30 text-white border-white/40 hover:bg-white/10"
      : tone === "gray"
      ? "bg-black/30 text-slate-200 border-gray-500/60 hover:bg-gray-500/15"
      : "bg-black/30 text-white border-white/10 hover:bg-black/40";

  return (
    <button type="button" onClick={onClick} className={`${base} ${active ? activeCls : inactiveCls}`}>
      <span>{label}</span>
      <span className={`tabular-nums px-2 py-0.5 rounded-full ${active ? "bg-black/20" : "bg-white/10"}`}>
        {count}
      </span>
    </button>
  );
}

/** ===== Verbod detectie =====
 *  We herkennen 'verbod' breed op basis van rule_code/rule/boodschap.
 *  Pas gerust de keywords aan aan jouw rule_codes.
 */
function isVerbodRow(r: ResRow) {
  const code = String(r.rule_code ?? "").toUpperCase();
  const rule = String(r.rule ?? "").toUpperCase();
  const msg = String(r.boodschap ?? "").toUpperCase();

  // Veelvoorkomend bij jullie: STARTVERBOD / VERBOD
  if (code.includes("STARTVERBOD")) return true;
  if (rule.includes("STARTVERBOD")) return true;
  if (msg.includes("STARTVERBOD")) return true;

  if (code.includes("VERBOD")) return true;
  if (rule.includes("VERBOD")) return true;
  if (msg.includes("VERBOD")) return true;

  // Eventueel: "NIET STARTGERECHTIGD"
  if (rule.includes("NIET START")) return true;
  if (msg.includes("NIET START")) return true;

  return false;
}

function isGeenTegenstander(ctx: AnyRow): boolean {
  const blauwVa = String(ctx?.blauw_va_mm ?? "").trim();
  const blauwNaam = String(ctx?.blauw_naam_fp ?? ctx?.blauw_naam_mm ?? "").trim();
  const roodVa = String(ctx?.rood_va_mm ?? "").trim();
  const roodNaam = String(ctx?.rood_naam_fp ?? ctx?.rood_naam_mm ?? "").trim();

  // “Partij bestaat” maar 1 kant leeg → meestal geen tegenstander
  const heeftRood = !!(roodVa || roodNaam);
  const heeftBlauw = !!(blauwVa || blauwNaam);

  return (heeftRood && !heeftBlauw) || (!heeftRood && heeftBlauw);
}

/** ===== Gala duur helpers (ongewijzigd) ===== */
function parseMinutesFromText(text: string): number | null {
  const m = String(text).match(/(\d+)\s*min/i);
  if (!m) return null;
  const n = Number(m[1]);
  return Number.isFinite(n) ? n : null;
}

function formatQuarterHoursFromMinutes(mins: number): string {
  const rounded = Math.round(mins / 15) * 15;
  const h = Math.floor(rounded / 60);
  const m = rounded % 60;

  const quarters = Math.round(m / 15);
  const frac = quarters === 0 ? "" : quarters === 1 ? " 1/4" : quarters === 2 ? " 1/2" : " 3/4";

  const prettyFrac = `${h}${frac} uur`;
  const hhmm = `${h}u ${String(m).padStart(2, "0")}m`;

  return `${prettyFrac} (${hhmm}, kwartier-afronding)`;
}

function isGalaDuurRow(r: ResRow) {
  const code = String(r.rule_code ?? "").toUpperCase();
  const rule = String(r.rule ?? "").toUpperCase();
  const msg = String(r.boodschap ?? "").toUpperCase();

  if (code.includes("GALA") && code.includes("DUUR")) return true;
  if (code.includes("EVENEMENT") && code.includes("DUUR")) return true;
  if (code.includes("TIJDSDUUR")) return true;

  if (rule.includes("GALA") && rule.includes("DUUR")) return true;
  if (rule.includes("TIJDSDUUR")) return true;
  if (rule.includes("EVENEMENT") && rule.includes("DUUR")) return true;

  if (msg.includes("GALA") && msg.includes("DUUR")) return true;
  if (msg.includes("TIJDSDUUR")) return true;
  if (msg.includes("EVENEMENT") && msg.includes("DUUR")) return true;

  if (rule.includes("DUURT TE LANG")) return true;
  if (msg.includes("DUURT TE LANG")) return true;

  return false;
}

function buildGalaDuurSamenvatting(runMeldingen: ResRow[]) {
  const hit = runMeldingen.find(isGalaDuurRow);
  if (!hit?.boodschap) return null;

  const mins = parseMinutesFromText(hit.boodschap);

  const approvalMin = 390; // 6.5u
  const maxMin = 510; // 8.5u

  if (!mins) {
    return { mins: null as number | null, needsApproval: true, overMax: false, text: hit.boodschap };
  }

  const needsApproval = mins > approvalMin;
  const overMax = mins > maxMin;

  let extra = "";
  if (overMax) extra = `⚠️ Overschrijdt max 8.5 uur (510 min) — AFKEUR.`;
  else if (needsApproval) extra = `⚠️ Boven 6.5 uur: Superadmin-goedkeuring nodig.`;
  else extra = `Binnen 6.5 uur (geen goedkeuring nodig).`;

  const q = formatQuarterHoursFromMinutes(mins);

  return { mins, needsApproval, overMax, text: `Tijdsduur evenement: ${q}. ${extra}` };
}

export default function ControleMatchmakingPage() {
  const params = useParams();
  const router = useRouter();
  const matchmakingId = params?.matchmakingId as string;

  const [reloadTick, setReloadTick] = useState(0);
  const [galaReviewLoading, setGalaReviewLoading] = useState<null | "approve" | "reject">(null);

  const [loading, setLoading] = useState(true);
  const [run, setRun] = useState<ControleRun | null>(null);

  // ✅ event header info (uit matchmaking_uploads / events)
  const [evenementNaam, setEvenementNaam] = useState<string | null>(null);
  const [evenementDatum, setEvenementDatum] = useState<string | null>(null);

  const [rows, setRows] = useState<AnyRow[]>([]);
  const [statusByPartij, setStatusByPartij] = useState<Record<number, PartijStatus>>({});
  const [runMeldingen, setRunMeldingen] = useState<ResRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string>("");

  const [busyPartij, setBusyPartij] = useState<Record<number, string>>({});

  const [hasDispByPartij, setHasDispByPartij] = useState<Record<number, boolean>>({});
  const [dispRequestByPartij, setDispRequestByPartij] = useState<Record<number, boolean>>({});
  const [countByPartij, setCountByPartij] = useState<Record<number, number>>({});

  // ✅ nieuw: verbod map
  const [verbodByPartij, setVerbodByPartij] = useState<Record<number, boolean>>({});

  const [filter, setFilter] = useState<FilterKey>("all");

  // ✅ role + user info
  const [role, setRole] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState<string | null>(null);

  const roleNorm = useMemo(() => String(role ?? "").trim().toLowerCase(), [role]);
  const isAdminOrSuper = useMemo(() => roleNorm === "admin" || roleNorm === "superadmin", [roleNorm]);

  function openReportHtml() {
    const url = `/dashboard/officials/controle/${encodeURIComponent(matchmakingId)}/rapport`;
    router.push(url);
  }

  function openExcel() {
    const url = `/api/rapport/excel?matchmaking_id=${encodeURIComponent(matchmakingId)}`;
    window.open(url, "_blank");
  }

  function openSportdataCsv() {
    const url = `/api/rapport/sportdata-csv?matchmaking_id=${encodeURIComponent(matchmakingId)}`;
    window.open(url, "_blank");
  }

  async function getAccessToken(): Promise<string | null> {
    const { data } = await supabase.auth.getSession();
    return data.session?.access_token ?? null;
  }

  function asUuid(v: any): string | null {
    if (v == null) return null;

    if (typeof v === "object") {
      const o: any = v;
      const cand =
        (typeof o.bout_id === "string" && o.bout_id) ||
        (typeof o.bout_uid === "string" && o.bout_uid) ||
        (typeof o.id === "string" && o.id);
      return asUuid(cand);
    }

    const s = String(v).trim();
    if (!s || s === "[object Object]") return null;

    const low = s.toLowerCase();
    if (low === "null" || low === "undefined") return null;

    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
    if (!isUuid) return null;

    return s;
  }

  async function sendToDispensatie(row: AnyRow) {
    const pn = Number(row?.partij_nr);
    const matchmaking_id = asUuid(matchmakingId);
    const bout_id = asUuid(row?.bout_id);

    if (!matchmaking_id) {
      setError("matchmakingId ontbreekt.");
      return;
    }
    if (!Number.isFinite(pn)) {
      setError("partij_nr ontbreekt.");
      return;
    }
    if (!bout_id) {
      console.error("[dispensatie] missing bout_id", { row });
      setError("Kan niet naar dispensatie sturen: bout_id ontbreekt (controle_bout_context).");
      return;
    }

    setBusyPartij((m) => ({ ...m, [pn]: "dispensatie" }));
    setError(null);
    setMsg("");

    try {
      const token = await getAccessToken();
      if (!token) throw new Error("Niet ingelogd.");

      const resp = await authedFetch("/api/dispensatie/upsert", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          matchmaking_id,
          partij_nr: pn,
          bout_id,
          rule_code: "MANUAL_PARTIJ",
        }),
      });

      const json = await resp.json().catch(() => ({}));
      if (!resp.ok) throw new Error(json?.error ?? "Naar dispensatie sturen mislukt");

      setMsg(`✅ Partij ${pn} naar dispensatie gestuurd.`);
      await load();
    } catch (e: any) {
      setError(e?.message ?? String(e));
    } finally {
      setBusyPartij((m) => {
        const cp = { ...m };
        if (Number.isFinite(pn)) delete cp[pn];
        return cp;
      });
    }
  }

  async function deletePartij(row: AnyRow) {
    const pn = Number(row?.partij_nr);
    if (!Number.isFinite(pn)) {
      setError("partij_nr ontbreekt.");
      return;
    }

    if (!isAdminOrSuper) {
      setError("Alleen admin/superadmin kan partijen verwijderen.");
      return;
    }

    const ok = window.confirm(
      `Weet je zeker dat je partij ${pn} wilt verwijderen?\n\nDit verwijdert context + resultaten + dispensatie_requests + (indien mogelijk) de bout.`
    );
    if (!ok) return;

    setBusyPartij((m) => ({ ...m, [pn]: "delete" }));
    setError(null);
    setMsg("");

    try {
      const token = await getAccessToken();
      if (!token) throw new Error("Niet ingelogd.");

      const resp = await authedFetch("/api/matchmaking/delete-partij", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          matchmaking_id: matchmakingId,
          partij_nr: pn,
          controle_run_id: run?.id ?? null,
          bout_id: row?.bout_id ?? null,
        }),
      });

      const json = await resp.json().catch(() => ({}));
      if (!resp.ok) throw new Error(json?.error ?? "Verwijderen mislukt");

      setMsg(`🗑️ Partij ${pn} verwijderd.`);
      setReloadTick((x) => x + 1);
    } catch (e: any) {
      setError(e?.message ?? String(e));
    } finally {
      setBusyPartij((m) => {
        const cp = { ...m };
        if (Number.isFinite(pn)) delete cp[pn];
        return cp;
      });
    }
  }

  async function getUserRole() {
    try {
      const { data: auth } = await supabase.auth.getUser();
      const user = auth?.user;
      if (!user) return;

      setUserId(user.id ?? null);
      setUserEmail(user.email ?? null);

      const norm = (v: any) => String(v ?? "").trim().toLowerCase();

      const metaRole =
        (user.app_metadata as any)?.role ??
        (user.user_metadata as any)?.role ??
        (user.app_metadata as any)?.user_role ??
        (user.user_metadata as any)?.user_role ??
        null;

      if (metaRole) {
        setRole(norm(metaRole));
        return;
      }

      const { data: prof, error: profErr } = await supabase
        .from("user_profiles")
        .select("role")
        .eq("id", user.id)
        .maybeSingle();

      if (!profErr && prof?.role) {
        setRole(norm(prof.role));
        return;
      }

      const { data: ur, error: urErr } = await supabase
        .from("user_roles")
        .select("roles(name)")
        .eq("user_id", user.id)
        .limit(1)
        .maybeSingle();

      if (!urErr) {
        const name = (ur as any)?.roles?.name ?? null;
        if (name) {
          setRole(norm(name));
          return;
        }
      }

      setRole(null);
    } catch {
      setRole(null);
    }
  }

  // ✅ Approval knop: admin/super altijd, hoofdofficial alleen assigned (server checkt)
  const galaDuur = useMemo(() => buildGalaDuurSamenvatting(runMeldingen), [runMeldingen]);

  const showApproveButton = useMemo(() => {
    if (!galaDuur) return false;
    if (!galaDuur.needsApproval) return false;
    if (galaDuur.overMax) return false;
    return roleNorm === "superadmin";
  }, [galaDuur, roleNorm]);

  const showRejectButton = useMemo(() => {
    if (!galaDuur) return false;
    if (!galaDuur.needsApproval) return false;
    return roleNorm === "admin" || roleNorm === "superadmin";
  }, [galaDuur, roleNorm]);

  async function approveGalaDuur() {
    if (!matchmakingId || !run?.id) return;

    setError(null);
    setMsg("");

    try {
      const resp = await authedFetch("/api/control-engine/approve-gala-duur", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          matchmaking_id: matchmakingId,
          controle_run_id: run.id,
          user_id: userId,
          user_email: userEmail,
        }),
      });

      const json = await resp.json().catch(() => ({}));
      if (!resp.ok) throw new Error(json?.error ?? "Toestemming opslaan mislukt");

      setMsg("✅ Toestemming voor gala-duur opgeslagen.");
      await load();
    } catch (e: any) {
      setError(e?.message ?? String(e));
    }
  }

  async function rejectGalaDuur() {
    try {
      setError(null);
      setMsg("");

      if (!matchmakingId) throw new Error("matchmaking_id ontbreekt");

      const token = await getAccessToken();
      if (!token) throw new Error("Niet ingelogd.");

      const resp = await authedFetch("/api/control-engine/reject-gala-duur", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ matchmaking_id: matchmakingId }),
      });

      const json = await resp.json().catch(() => ({}));
      if (!resp.ok) throw new Error(json?.error ?? "Afkeuren mislukt");

      setMsg("⚠️ Gala-duur is afgekeurd. Matchmaker moet minder partijen plannen.");
      await load();
    } catch (e: any) {
      setError(e?.message ?? String(e));
    }
  }

  async function load() {
    setLoading(true);
    setError(null);
    setMsg("");

    try {
      if (!matchmakingId) {
        setRows([]);
        setRun(null);
        setEvenementNaam(null);
        setEvenementDatum(null);
        setStatusByPartij({});
        setRunMeldingen([]);
        setHasDispByPartij({});
        setDispRequestByPartij({});
        setCountByPartij({});
        setVerbodByPartij({});
        return;
      }

      // 0) event info ophalen (naam + datum) voor header
      try {
        const { data: ups, error: upErr } = await supabase
          .from("matchmaking_uploads")
          .select("evenement_naam, evenement_datum, event_id")
          .eq("matchmaking_id", matchmakingId)
          .order("uploaded_at", { ascending: false })
          .limit(1);

        if (upErr) throw upErr;

        const up = (ups ?? [])?.[0] as any;
        let naam = String(up?.evenement_naam ?? "").trim() || null;
        let datum = String(up?.evenement_datum ?? "").trim() || null;
        const eventId = String(up?.event_id ?? "").trim() || null;

        if (eventId && (!naam || !datum)) {
          const { data: ev, error: evErr } = await supabase
            .from("events")
            .select("naam, datum")
            .eq("id", eventId)
            .maybeSingle();
          if (evErr) throw evErr;
          if (!naam) naam = String((ev as any)?.naam ?? "").trim() || null;
          if (!datum) datum = String((ev as any)?.datum ?? "").trim() || null;
        }

        setEvenementNaam(naam);
        setEvenementDatum(datum);
      } catch {
        // header info is nice-to-have; nooit de hele pagina breken
        setEvenementNaam(null);
        setEvenementDatum(null);
      }

      // 1) laatste controle_run_id uit controle_bout_context
      const { data: lastCtxRows, error: lastErr } = await supabase
        .from("controle_bout_context")
        .select("controle_run_id, created_at")
        .eq("matchmaking_id", matchmakingId)
        .order("created_at", { ascending: false })
        .limit(1);

      if (lastErr) throw lastErr;

      const latestControleRunId = lastCtxRows?.[0]?.controle_run_id ? String(lastCtxRows[0].controle_run_id) : null;

      setRun(
        latestControleRunId
          ? ({
              id: latestControleRunId,
              matchmaking_id: matchmakingId,
              status: "unknown",
              gestart_op: null,
              afgerond_op: null,
              run_type: null,
            } as ControleRun)
          : null
      );

      // 2) context rows (alleen nieuwste run)
      let ctxQuery = supabase.from("controle_bout_context").select("*").eq("matchmaking_id", matchmakingId);
      if (latestControleRunId) ctxQuery = ctxQuery.eq("controle_run_id", latestControleRunId);

      const { data: ctxRows, error: ctxErr } = await ctxQuery.order("partij_nr", { ascending: true });
      if (ctxErr) throw ctxErr;

      const ctxList = (ctxRows ?? []) as AnyRow[];
      setRows(ctxList);

      // 3) status map init: ok vs geen_info
      const map: Record<number, PartijStatus> = {};
      const ctxByPn: Record<number, AnyRow> = {};

      for (const r of ctxList) {
        const pn = Number(r.partij_nr);
        if (!Number.isFinite(pn)) continue;
        ctxByPn[pn] = r;
        map[pn] = isContextCompleet(r) ? "ok" : "geen_info";
      }

      if (!latestControleRunId) {
        setStatusByPartij(map);
        setRunMeldingen([]);
        setHasDispByPartij({});
        setDispRequestByPartij({});
        setCountByPartij({});
        setVerbodByPartij({});
        return;
      }

      // 4) resultaten ophalen
      const { data: resRows, error: resErr } = await supabase
        .from("controle_resultaten")
        .select("partij_nr, bout_id, hoek, resultaat, rule, rule_code, boodschap")
        .eq("controle_run_id", latestControleRunId);

      if (resErr) throw resErr;

      const allRes = (resRows ?? []) as ResRow[];

      // run-level
      const runRows = allRes.filter((r) => {
        const pn = (r as any)?.partij_nr;
        const isRunPn = pn == null || Number(pn) === 0;
        const isRunBout = (r as any)?.bout_id == null;
        return isRunPn && isRunBout;
      });
      setRunMeldingen(runRows);

      // meldingen count + per partij
      const cntMap: Record<number, number> = {};
      const per: Record<number, ResRow[]> = {};

      for (const rr of allRes) {
        const pn = Number(rr.partij_nr);
        if (!Number.isFinite(pn)) continue;

        per[pn] = per[pn] ?? [];
        per[pn].push(rr);

        cntMap[pn] = (cntMap[pn] ?? 0) + 1;
      }

      // ✅ verbod per partij
      const verbodMap: Record<number, boolean> = {};
      for (const [pnStr, arr] of Object.entries(per)) {
        const pn = Number(pnStr);
        if (!Number.isFinite(pn)) continue;
        if ((arr ?? []).some(isVerbodRow)) verbodMap[pn] = true;
      }
      setVerbodByPartij(verbodMap);

      // ✅ DISPENSATIE meldingen (uit rules) per partij_nr
      const dispRulePn = new Set<number>();
      for (const [pnStr, arr] of Object.entries(per)) {
        const pn = Number(pnStr);
        if (!Number.isFinite(pn)) continue;
        if ((arr ?? []).some((x) => normResultaat((x as any)?.resultaat) === "dispensatie")) {
          dispRulePn.add(pn);
        }
      }

      const dispRuleMap: Record<number, boolean> = {};
      for (const pn of dispRulePn) dispRuleMap[pn] = true;

      setCountByPartij(cntMap);

      // dispensatie requests per partij
      const dispAnyMap: Record<number, boolean> = {};
      const dispOpenMap: Record<number, boolean> = {};

      const rejectedPn = new Set<number>();
      const pendingPn = new Set<number>();
      const dispAnyPn = new Set<number>();

      try {
        const token = await getAccessToken();
        let dispReqs: any[] = [];

        if (token) {
          const r = await fetch(`/api/dispensatie/by-matchmaking?matchmaking_id=${matchmakingId}`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          const j = await r.json().catch(() => ({}));
          if (r.ok) dispReqs = (j?.rows ?? []) as any[];
        }

        if (!dispReqs.length) {
          const { data, error } = await supabase
            .from("dispensatie_requests")
            .select("status, decision, partij_nr, bout_id")
            .eq("matchmaking_id", matchmakingId);

          if (!error) dispReqs = (data ?? []) as any[];
        }

        for (const dr of dispReqs ?? []) {
          const st = String((dr as any)?.status ?? "").toLowerCase().trim();
          const dec = String((dr as any)?.decision ?? "").toLowerCase().trim();
          const pn = Number((dr as any)?.partij_nr);
          if (!Number.isFinite(pn)) continue;

          dispAnyPn.add(pn);
          if (st === "open" || st === "nieuw" || st === "pending" || st === "tied") pendingPn.add(pn);
          if (st === "rejected" || dec === "afkeur" || st === "afgekeurd") rejectedPn.add(pn);
        }
      } catch {
        // ignore
      }

      // 6) status per partij (zwaarste telt; rejected override)
      for (const pnStr of Object.keys(ctxByPn)) {
        const pn = Number(pnStr);
        let s = statusFromResultatenOrOk(per[pn], ctxByPn[pn]);

        if (rejectedPn.has(pn)) s = "afgekeurd";
        map[pn] = s;

        if (dispRulePn.has(pn) && s !== "afgekeurd" && s !== "geen_info") {
          s = "dispensatie";
          map[pn] = s;
        }

        if (dispAnyPn.has(pn)) {
          dispAnyMap[pn] = true;
        }

        if (pendingPn.has(pn)) {
          dispOpenMap[pn] = true;
          if (s !== "afgekeurd") {
            s = "dispensatie";
            map[pn] = s;
          }
        }
      }

      setHasDispByPartij(dispRuleMap);
      setDispRequestByPartij(dispAnyMap);
      setStatusByPartij(map);
    } catch (e: any) {
      setError(e?.message ?? String(e));
      setRows([]);
      setRun(null);
      setStatusByPartij({});
      setRunMeldingen([]);
      setHasDispByPartij({});
      setDispRequestByPartij({});
      setCountByPartij({});
      setVerbodByPartij({});
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    getUserRole();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matchmakingId, reloadTick]);

  async function reviewGalaDuur(action: "approve" | "reject") {
    try {
      setGalaReviewLoading(action);
      setError(null);
      setMsg("");

      const { data: sess } = await supabase.auth.getSession();
      const token = sess?.session?.access_token ?? null;
      if (!token) throw new Error("Niet ingelogd.");

      const r = await authedFetch("/api/control-engine/review-gala-duur", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ matchmaking_id: matchmakingId, action }),
      });

      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j?.error ?? "Gala-duur review mislukt");

      setMsg(action === "approve" ? "✅ Gala-duur goedgekeurd." : "✅ Gala-duur afgekeurd.");
      setReloadTick((x) => x + 1);
    } catch (e: any) {
      setError(e?.message ?? String(e));
    } finally {
      setGalaReviewLoading(null);
    }
  }

  const subtitle = useMemo(() => {
    if (!matchmakingId) return "Geen matchmakingId";
    const runInfo = run?.id ? `RunId: ${run.id}` : "Geen run-id gevonden";
    const evNaam = (evenementNaam ?? "").trim();
    const evDatum = (evenementDatum ?? "").trim();
    const evTxt = evNaam || evDatum ? `${evNaam || "(geen eventnaam)"} • ${evDatum || "(geen datum)"}` : "(geen event gekoppeld)";
    return `${evTxt} • Matchmaking ${matchmakingId} • ${runInfo}`;
  }, [matchmakingId, run, evenementNaam, evenementDatum]);

  function isLicentieOk(v: any): boolean {
    const s = String(v ?? "").trim().toLowerCase();
    if (!s) return false;
    return s === "ja" || s === "yes" || s === "true" || s === "1";
  }

  const licentieMissingCount = useMemo(() => {
    let c = 0;
    for (const r of rows ?? []) {
      if (!isLicentieOk((r as any)?.rood_licentie)) c += 1;
      if (!isLicentieOk((r as any)?.blauw_licentie)) c += 1;
    }
    return c;
  }, [rows]);

  const totals = useMemo(() => {
    let afk = 0,
      dispStatus = 0,
      actie = 0,
      ok = 0,
      geen = 0;

    for (const r of rows) {
      const pn = Number(r.partij_nr);
      const s = Number.isFinite(pn) ? statusByPartij[pn] ?? "geen_info" : "geen_info";
      if (s === "afgekeurd") afk++;
      else if (s === "dispensatie") dispStatus++;
      else if (s === "actie") actie++;
      else if (s === "ok") ok++;
      else geen++;
    }

    const dispHitCount = Object.values(hasDispByPartij).filter(Boolean).length;
    const verbodCount = Object.values(verbodByPartij).filter(Boolean).length;

    const runCount = runMeldingen.length;
    const partijenMetMelding = Object.values(countByPartij).reduce((acc, n) => acc + (Number(n) > 0 ? 1 : 0), 0);
    const partijMeldingenTotaal = Object.values(countByPartij).reduce((a, b) => a + (Number(b) || 0), 0);

    return {
      totaal: rows.length,
      afk,
      verbod: verbodCount,
      dispensatie: dispHitCount,
      disp_status: dispStatus,
      actie,
      ok,
      geen,
      run: runCount,
      partijen_met_melding: partijenMetMelding,
      meldingen_totaal: partijMeldingenTotaal + runCount,
    };
  }, [rows, statusByPartij, runMeldingen, countByPartij, hasDispByPartij, verbodByPartij]);

  const rowsByPartijNr = useMemo(() => {
    const copy = [...rows];
    copy.sort((a, b) => Number(a.partij_nr ?? 0) - Number(b.partij_nr ?? 0));
    return copy;
  }, [rows]);

  const filterCounts = useMemo(() => {
    let afk = 0,
      disp = 0,
      actie = 0,
      ok = 0,
      geen = 0,
      verbod = 0;

    for (const r of rows) {
      const pn = Number(r.partij_nr);
      if (!Number.isFinite(pn)) continue;

      const s = statusByPartij[pn] ?? "geen_info";
      if (s === "afgekeurd") afk++;
      else if (s === "actie") actie++;
      else if (s === "ok") ok++;
      else geen++;

      if (hasDispByPartij[pn]) disp++;
      if (verbodByPartij[pn]) verbod++;
    }

    return { all: rows.length, verbod, afgekeurd: afk, dispensatie: disp, actie, ok, geen_info: geen };
  }, [rows, statusByPartij, hasDispByPartij, verbodByPartij]);

  const filteredRows = useMemo(() => {
    if (filter === "all") return rowsByPartijNr;

    return rowsByPartijNr.filter((r) => {
      const pn = Number(r.partij_nr);
      if (!Number.isFinite(pn)) return false;

      if (filter === "dispensatie") return !!hasDispByPartij[pn];
      if (filter === "verbod") return !!verbodByPartij[pn];

      const s = statusByPartij[pn] ?? "geen_info";
      return s === filter;
    });
  }, [rowsByPartijNr, filter, statusByPartij, hasDispByPartij, verbodByPartij]);

  return (
    <TableCardLayout title="Controle – Overzicht" subtitle={subtitle} backHref="/dashboard/officials/controle" backLabel="Terug">
      {loading ? (
        <div className="text-white/70">Laden…</div>
      ) : error ? (
        <div className="text-red-200">{error}</div>
      ) : rows.length === 0 ? (
        <div className="text-white/70">Geen context gevonden (context nog niet gevuld?).</div>
      ) : (
        <div className="space-y-3">
          {/* Header badges */}
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-sm text-white/80">
              Partijen: <span className="text-white font-semibold">{totals.totaal}</span>
            </span>

            <HeaderBadge label="Meldingen totaal" value={totals.meldingen_totaal} tone="white" />
            <HeaderBadge label="Partijen met melding" value={totals.partijen_met_melding} tone="white" />

            <HeaderBadge label="Verbod" value={totals.verbod} tone="purple" />
            <HeaderBadge label="Afkeur" value={totals.afk} tone="red" />
            <HeaderBadge label="Dispensatie" value={totals.dispensatie} tone="orange" />
            <HeaderBadge label="Actie" value={totals.actie} tone="yellow" />
            <HeaderBadge label="OK" value={totals.ok} tone="green" />
            <HeaderBadge label="Geen info" value={totals.geen} tone="white" />

            <HeaderBadge label="Licentie ontbreekt" value={licentieMissingCount} tone="blue" />

            <div className="ml-auto flex flex-wrap gap-2">
              <button
                type="button"
                onClick={openSportdataCsv}
                className="px-3 py-1.5 rounded bg-purple-700 text-white text-sm font-extrabold hover:opacity-90"
                title="Download CSV in Sportdata-import formaat"
              >
                CSV Sportdata
              </button>

              <button
                type="button"
                onClick={openExcel}
                className="px-3 py-1.5 rounded bg-green-600 text-white text-sm font-extrabold hover:opacity-90"
                title="Download Excel overzicht (filters/sorteren)"
              >
                Excel
              </button>

              <button
                type="button"
                onClick={openReportHtml}
                className="px-3 py-1.5 rounded bg-[var(--brand-orange)] text-black text-sm font-extrabold hover:opacity-90"
              >
                Rapportage
              </button>
            </div>
          </div>

          {/* Gala duur + Toestemming */}
          {galaDuur?.text ? (
            <div className={`rounded-lg border border-white/10 p-3 text-sm ${galaDuur.overMax ? "bg-red-500/10" : "bg-white/5"}`}>
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-semibold text-white">Gala duur:</span>
                <span className="text-white/80">{galaDuur.text}</span>

                {showApproveButton ? (
                  <button
                    type="button"
                    onClick={approveGalaDuur}
                    className="ml-auto px-3 py-1.5 rounded bg-[var(--brand-orange)] text-black text-xs font-extrabold hover:opacity-90"
                    title={isAdminOrSuper ? "Superadmin kan goedkeuren" : "Alleen superadmin kan goedkeuren"}
                  >
                    Goedkeur
                  </button>
                ) : null}

                {showRejectButton ? (
                  <button
                    type="button"
                    onClick={rejectGalaDuur}
                    className="px-3 py-1.5 rounded bg-red-600 text-white text-xs font-extrabold hover:opacity-90"
                    title="Afkeuren: matchmaker moet minder partijen plannen (waarschuwing verschijnt in rapport)"
                  >
                    Afkeur
                  </button>
                ) : null}

                {galaReviewLoading ? <span className="text-xs text-white/60">…</span> : null}
              </div>
            </div>
          ) : null}

          {/* Run meldingen */}
          {runMeldingen.length > 0 && (
            <div className="mt-3 rounded-lg border border-white/10 bg-white/5 p-4">
              <div className="font-semibold">Run meldingen</div>
              <div className="mt-2 space-y-2 text-sm">
                {runMeldingen.map((r, i) => (
                  <div key={i} className="rounded-md bg-black/30 border border-white/10 p-2">
                    <div className="flex items-center gap-2">
                      <span className="text-white/80 font-semibold">{r.rule ?? "(run)"}</span>
                      {r.rule_code ? <span className="text-xs text-white/50">({r.rule_code})</span> : null}
                      <span className="ml-auto text-xs text-white/60">{String(r.resultaat ?? "").toUpperCase()}</span>
                    </div>
                    {r.boodschap && <div className="text-white/70">{r.boodschap}</div>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {msg ? <div className="text-sm text-white/70">{msg}</div> : null}

          {/* Filterbalk */}
          <div className="flex flex-wrap items-center gap-2 rounded-lg border border-white/10 bg-white/5 p-3">
            <div className="text-sm font-semibold text-white/80 mr-2">Filter:</div>

            <FilterButton label="Alle" count={filterCounts.all} tone="neutral" active={filter === "all"} onClick={() => setFilter("all")} />
            <FilterButton label="Verbod" count={filterCounts.verbod} tone="purple" active={filter === "verbod"} onClick={() => setFilter("verbod")} />
            <FilterButton label="Afkeur" count={filterCounts.afgekeurd} tone="red" active={filter === "afgekeurd"} onClick={() => setFilter("afgekeurd")} />
            <FilterButton
              label="Dispensatie"
              count={filterCounts.dispensatie}
              tone="orange"
              active={filter === "dispensatie"}
              onClick={() => setFilter("dispensatie")}
            />
            <FilterButton label="Actie" count={filterCounts.actie} tone="yellow" active={filter === "actie"} onClick={() => setFilter("actie")} />
            <FilterButton label="OK" count={filterCounts.ok} tone="green" active={filter === "ok"} onClick={() => setFilter("ok")} />
            <FilterButton
              label="Geen info"
              count={filterCounts.geen_info}
              tone="white"
              active={filter === "geen_info"}
              onClick={() => setFilter("geen_info")}
            />

            <div className="ml-auto text-xs text-white/60">
              Toon: <span className="font-semibold text-white">{filteredRows.length}</span>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-auto rounded-md border border-white/10">
            <table className="min-w-full border-collapse">
              <thead className="bg-[var(--brand-orange)] text-white">
                <tr>
                  <th className="py-3 px-4 text-left w-24">#</th>
                  <th className="py-3 px-4 text-left">Vechters</th>
                  <th className="py-3 px-4 text-left w-[320px]">Info</th>
                  <th className="py-3 px-4 text-left w-[360px]">Acties</th>
                </tr>
              </thead>

              <tbody>
                {filteredRows.map((r, i) => {
                  const zebraWhite = i % 2 === 0;

                  const roodNaam = safeText(r.rood_naam_fp ?? r.rood_naam_mm, "-");
                  const blauwNaam = safeText(r.blauw_naam_fp ?? r.blauw_naam_mm, "-");

                  const roodGym = safeText(r.rood_gym_mm, "-");
                  const blauwGym = safeText(r.blauw_gym_mm, "-");

                  const roodVA = safeText(r.rood_va_mm, "-");
                  const blauwVA = safeText(r.blauw_va_mm, "-");

                  const roodAge = ageAtEvent(r, "rood");
                  const blauwAge = ageAtEvent(r, "blauw");

                  const pn = Number(r.partij_nr);
                  const status = Number.isFinite(pn) ? statusByPartij[pn] ?? "geen_info" : "geen_info";

                  const discipline = safeText(r.discipline, "-");
                  const klasse = safeText(r.klasse_mm, "-");
                  const eventDatum = safeText(r.evenement_datum, "-");

                  const dividerClass = zebraWhite ? "border-t border-gray-600/60" : "border-t border-[var(--brand-orange)]/80";

                  const heeftDispHit = Number.isFinite(pn) ? !!hasDispByPartij[pn] : false;
                  const heeftDispRequest = Number.isFinite(pn) ? !!dispRequestByPartij[pn] : false;

                  const heeftVerbod = Number.isFinite(pn) ? !!verbodByPartij[pn] : false;
                  const geenTegenstander = isGeenTegenstander(r);

                  return (
                    <tr
                      key={r.id ?? `${r.partij_nr}-${i}`}
                      style={{
                        backgroundColor: zebraWhite ? "#ffffff" : "#0d0d0d",
                        color: zebraWhite ? "#000" : "#fff",
                      }}
                    >
                      <td className="py-3 px-4 font-semibold align-top">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="tabular-nums">{r.partij_nr ?? "-"}</span>
                          <StatusBadge status={status} />

                          {heeftVerbod ? <Chip label="VERBOD" tone="purple" /> : null}

                          {(heeftDispHit || heeftDispRequest) && status !== "dispensatie" ? (
                            <StatusBadge status="dispensatie" />
                          ) : null}
                        </div>
                      </td>

                      <td className="py-3 px-4 align-top">
                        <div className="flex items-center gap-3 min-w-0">
                          <span className="inline-block w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: "#ef4444" }} />
                          <div className="min-w-0 text-sm">
                            <span className="font-semibold">{roodNaam}</span>{" "}
                            <span className="opacity-80">({roodAge} jaar)</span>{" "}
                            <span className="opacity-80">• {roodGym}</span>{" "}
                            <span className="opacity-80">• FP/VA: {roodVA}</span>
                          </div>
                        </div>

                        <div className={`my-2 ${dividerClass}`} />

                        <div className="flex items-center gap-3 min-w-0">
                          <span className="inline-block w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: "#3b82f6" }} />
                          <div className="min-w-0 text-sm">
                            <span className="font-semibold">{blauwNaam}</span>{" "}
                            <span className="opacity-80">({blauwAge} jaar)</span>{" "}
                            <span className="opacity-80">• {blauwGym}</span>{" "}
                            <span className="opacity-80">• FP/VA: {blauwVA}</span>
                          </div>
                        </div>

                        {geenTegenstander ? (
                          <div className="mt-2 text-xs font-extrabold">
                            <span className="px-2 py-1 rounded bg-red-500 text-white">GEEN TEGENSTANDER</span>
                          </div>
                        ) : null}
                      </td>

                      <td className="py-3 px-4 align-top">
                        <div className="space-y-1 text-sm">
                          <div>
                            <span className="font-semibold">Discipline:</span>{" "}
                            <span className="opacity-90">{discipline}</span>
                          </div>
                          <div>
                            <span className="font-semibold">Klasse:</span>{" "}
                            <span className="opacity-90">{klasse}</span>
                          </div>
                          <div>
                            <span className="font-semibold">Event:</span>{" "}
                            <span className="opacity-90">{eventDatum}</span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4 align-top">
                        <div className="flex flex-wrap gap-2">
                          <Link
                            href={`/dashboard/officials/controle/${matchmakingId}/${r.partij_nr}`}
                            className="inline-flex items-center px-2 py-1 rounded bg-black text-white text-xs font-semibold hover:bg-[var(--brand-orange)] hover:text-black transition"
                          >
                            Details →
                          </Link>

                          <button
                            type="button"
                            onClick={() => sendToDispensatie(r)}
                            disabled={!!busyPartij[Number(r.partij_nr)] || heeftDispRequest}
                            className={
                              heeftDispRequest
                                ? "inline-flex items-center px-2 py-1 rounded bg-zinc-400 text-black text-xs font-extrabold opacity-90 cursor-default"
                                : "inline-flex items-center px-2 py-1 rounded bg-orange-600 text-white text-xs font-extrabold hover:opacity-90 disabled:opacity-50"
                            }
                            title={heeftDispRequest ? "Deze partij is al naar dispensatie gestuurd" : "Stuur deze partij naar Dispensatie (admin actie)"}
                          >
                            {busyPartij[Number(r.partij_nr)] === "dispensatie" ? "…" : heeftDispRequest ? "Dispensatie ✓" : "Dispensatie"}
                          </button>

                          {isAdminOrSuper ? (
                            <button
                              type="button"
                              onClick={() => deletePartij(r)}
                              disabled={!!busyPartij[Number(r.partij_nr)]}
                              className="inline-flex items-center px-2 py-1 rounded bg-red-600 text-white text-xs font-extrabold hover:opacity-90 disabled:opacity-50"
                              title={geenTegenstander ? "Verwijder partij (geen tegenstander)" : "Verwijder partij"}
                            >
                              {busyPartij[Number(r.partij_nr)] === "delete" ? "…" : "Verwijder"}
                            </button>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </TableCardLayout>
  );
}